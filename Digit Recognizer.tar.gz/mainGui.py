import sys
import Model
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QApplication,QDialog
from PyQt5.uic import loadUi

class MainPage(QDialog):
    def __init__(self):
        super(MainPage, self).__init__()
        loadUi('gui.ui', self)
        self.pushButton.clicked.connect(self.retrieveInput)
        
    def retrieveInput(self):
        try:
            inp = int(self.plainTextEdit.toPlainText())
        except ValueError:
            from err_msg import ErrorPage
            obj = ErrorPage('Invalid Index value')
            obj.exec_()
            return
        result = Model.InputVar(inp)
        if result == -1:
            from err_msg import ErrorPage
            obj = ErrorPage('Index Out Of Bound')
            obj.exec_()
            return
        self.textEdit.setText(str(result[1][0]))
        self.textEdit_2.setText(str(result[0]))

app=QApplication(sys.argv)
widget=MainPage()
widget.show()
sys.exit(app.exec_())
		